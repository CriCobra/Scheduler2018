#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sysexits.h>
#include <stdlib.h>
#include <pthread.h>
#include <getopt.h>
#include "strutture_dati.h"

FILE *o_file;

void start_sched(Task *tasks, Istruzione *instructions, int n_task, char *f_output) {
    o_file = fopen(f_output, "w");
    if (o_file==NULL) {
        printf ("Impossibile aprire il file di output \n");
        return;
    }

    Task* task = NULL;
    Istruzione* instr = NULL;

    task = tasks;
    instr = instructions;


    pthread_t core_0;
    pthread_t core_1;







}





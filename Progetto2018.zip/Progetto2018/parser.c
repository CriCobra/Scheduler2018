#include "strutture_dati.h"
#include <mm_malloc.h>
#include <stdlib.h>
#include <stdio.h>


Task* parse (char *file_input, Task **tasks, Istruzione **istruzioni) {
    FILE *i_file;
    i_file = fopen(file_input, "r");

   if (i_file == NULL) {
        printf ("Impossibile aprire il file \n");
        return NULL;
    }

    int n_instr = 0;
    int n_task = 0;
    char c;

    //conto task e instr per allocare strutture
    while (!feof(i_file)) {
        fscanf(i_file, "%c", &c);
        if (c == 'i') {

            n_instr++;
        }
        else if (c == 't')
            n_task++;
    }

    Task *task = (Task*)malloc(n_task* sizeof(Task));
    Istruzione *istruzione = (Istruzione*)malloc(n_instr*sizeof(Istruzione));


    //riporto il puntatore del file all'inizio
    rewind(i_file);

    n_instr=0;
    n_task=0;
    int p = 0;

    fscanf(i_file, "%c", &c);
    while (!feof(i_file)) {
        fscanf(i_file, ",%d,%d", &task[n_task].id, &task[n_task].arrival_time);
        fscanf(i_file, "%c", &c);
        while (c == 'i') {
            fscanf(i_file, ",%d,%d", &istruzione[n_instr].type_flag, &istruzione[n_instr].length);
            fscanf(i_file, "%c", &c);
            n_instr++;
        }
        task[n_task].instr_list = &istruzione[p];
        p+=n_instr;
        n_task++;
        n_instr=0;
        printf("%d\n", task[n_task].id);

    }



    fclose(i_file);

    *tasks = task;
    *istruzioni = istruzione;


    return task;



}